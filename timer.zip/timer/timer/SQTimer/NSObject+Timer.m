//
//  NSObject+Timer.m
//  timer
//
//  Created by 孙强 on 2018/6/8.
//  Copyright © 2018年 孙强. All rights reserved.
//

#import "NSObject+Timer.h"
#import <objc/runtime.h>
#import "SQTimer.h"

static NSString *key = @"timerKey";

@implementation NSObject (Timer)

- (NSMutableDictionary *)timerCache {
    NSMutableDictionary *dict = objc_getAssociatedObject(self, &key);
    if (!dict) {
        self.timerCache = [NSMutableDictionary dictionaryWithCapacity:3];
        dict = self.timerCache;
    }
    return dict;
}

- (void)setTimerCache:(NSMutableDictionary *)timerCache {
    objc_setAssociatedObject(self, &key, timerCache, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (void)scheduledTimerWithTimeInterval:(NSTimeInterval)NSTimeInterval target:(id)target selector:(SEL)selector userInfo:(id)userInfo repeats:(BOOL)repeats key:(NSString *)key {
    SQTimer *timer = [SQTimer  alloc];
    timer.delegate = self;
    [timer scheduledTimerWithTimeInterval:NSTimeInterval target:target selector:selector userInfo:userInfo repeats:repeats];
    [self.timerCache setObject:timer forKey:key];
}

- (void)stopTimerWithKey:(NSString *)key {
    SQTimer *timer = [self.timerCache objectForKey:key];
    if (timer) {
        [timer.timer  invalidate];
        timer.timer = nil;
        [self.timerCache removeObjectForKey:key];
    }
}

- (void)timer:(SQTimer *)timer removeSelfWithKey:(NSString *)key {
    [self.timerCache removeObjectForKey:key];
}


@end
