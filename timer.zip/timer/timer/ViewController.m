//
//  ViewController.m
//  timer
//
//  Created by 孙强 on 2018/6/8.
//  Copyright © 2018年 孙强. All rights reserved.
//

#import "ViewController.h"
#import "TestViewController.h"
#import "NSObject+Timer.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    TestViewController *test = [TestViewController new];
    [self.navigationController pushViewController:test animated:YES];
}


//- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
//    [self stopTimerWithKey:@"test"];
//}

- (void)test {
    NSLog(@"123");
}
@end
