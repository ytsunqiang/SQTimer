//
//  SQTimer.h
//  timer
//
//  Created by 孙强 on 2018/6/8.
//  Copyright © 2018年 孙强. All rights reserved.
//

#import <Foundation/Foundation.h>
@class SQTimer;

NS_ASSUME_NONNULL_BEGIN

@protocol SQTimerDelegate <NSObject>

- (void)timer:(SQTimer *)timer removeSelfWithKey:(NSString *)key;

@end


@interface SQTimer : NSProxy

@property (nonatomic, strong, nullable) NSTimer *timer;

@property (nonatomic, copy, nullable) NSString *key;

@property (nonatomic, weak) id<SQTimerDelegate> delegate;

- (NSTimer *)scheduledTimerWithTimeInterval:(NSTimeInterval)NSTimeInterval target:(nonnull id)target selector:(nonnull SEL)selector userInfo:(nullable id)userInfo repeats:(BOOL)repeats;

@end
NS_ASSUME_NONNULL_END
