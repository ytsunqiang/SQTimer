//
//  NSObject+Timer.h
//  timer
//
//  Created by 孙强 on 2018/6/8.
//  Copyright © 2018年 孙强. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SQTimer.h"

NS_ASSUME_NONNULL_BEGIN

@interface NSObject (Timer)

@property (nonatomic, strong) NSMutableDictionary *timerCache;

- (void)scheduledTimerWithTimeInterval:(NSTimeInterval)NSTimeInterval target:(nonnull id)target selector:(nonnull SEL)selector userInfo:(nullable id)userInfo repeats:(BOOL)repeats key:(NSString *)key;

- (void)stopTimerWithKey:(NSString *)key;

@end
NS_ASSUME_NONNULL_END
