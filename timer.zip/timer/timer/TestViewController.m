//
//  TestViewController.m
//  timer
//
//  Created by 孙强 on 2018/6/8.
//  Copyright © 2018年 孙强. All rights reserved.
//

#import "TestViewController.h"
#import "NSObject+Timer.h"

@interface TestViewController ()

@end

@implementation TestViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self scheduledTimerWithTimeInterval:2 target:self
                                selector:@selector(test) userInfo:nil repeats:YES key:@"abc"];
    [self scheduledTimerWithTimeInterval:2 target:self
                                selector:@selector(test2) userInfo:nil repeats:YES key:@"abc1"];
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self stopTimerWithKey:@"abc1"];
}

- (void)test {
    NSLog(@"哈哈哈 我正在运行test1");
}

- (void)test2 {
    NSLog(@"哈哈哈 我正在运行test2");
}

- (void)dealloc {
    NSLog(@"哈哈哈 我销毁了");
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
