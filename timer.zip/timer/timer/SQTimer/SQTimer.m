//
//  SQTimer.m
//  timer
//
//  Created by 孙强 on 2018/6/8.
//  Copyright © 2018年 孙强. All rights reserved.
//

#import "SQTimer.h"

@interface SQTimer ()

@property (nonatomic, assign) SEL timerSel;

@property (nonatomic, weak) id target;

@end

@implementation SQTimer


- (NSTimer *)scheduledTimerWithTimeInterval:(NSTimeInterval)NSTimeInterval target:(id)target selector:(SEL)selector userInfo:(id)userInfo repeats:(BOOL)repeats {
    
    self.target = target;
    self.timerSel = selector;
    
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:NSTimeInterval target:self selector:selector userInfo:userInfo repeats:repeats];
    [[NSRunLoop currentRunLoop] addTimer:timer forMode:NSDefaultRunLoopMode];
    self.timer = timer;
    
    return timer;
}

- (id)forwardingTargetForSelector:(SEL)aSelector {
    
    NSLog(@"方法名 == %@",NSStringFromSelector(aSelector));
    if (!self.target) {
        [self.timer invalidate];
        self.timer = nil;
        if ([self.delegate respondsToSelector:@selector(timer:removeSelfWithKey:)]) {
            [self.delegate timer:self removeSelfWithKey:self.key];
        }
    }
    
    return self.target;
}


- (NSMethodSignature *)methodSignatureForSelector:(SEL)aSelector {
    if (aSelector == self.timerSel) {
        NSLog(@"method signature for selector: %@", NSStringFromSelector(aSelector));
        return [NSMethodSignature signatureWithObjCTypes:"V@:@"];
    }
    return [super methodSignatureForSelector:aSelector];
}

- (void)forwardInvocation:(NSInvocation *)anInvocation {
    void *nullValue = NULL;
    [anInvocation setReturnValue:&nullValue];
}

- (void)dealloc {
    NSLog(@"小强定时器销毁");
}

@end
